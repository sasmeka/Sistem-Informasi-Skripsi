<?= $this->include('Template/header') ?>
<?= $this->include('Template/sidebar') ?>	
<?= $this->include('Template/main-header') ?>	
<?= $this->renderSection('content') ?>	
<?= $this->include('Template/footer') ?>